const i18nConfig = {
    locales: ['en', 'fa'],
    defaultLocale: 'en'
    
  };
  
  module.exports = i18nConfig;