import React from 'react'

function NotFound() {
  return (
    <div>NotFound nothing sharks</div>
  )
}
  
export default NotFound;