import React from 'react';
import CprogressBar from '@/components/CprogressBar';


export default function Loading() {
  return <CprogressBar  />;
}
