import React from 'react'

export default function categoryLayout() {
  return (
    <div>categoryLayout</div>
  )
}
