import React from 'react'

export default function categoryPage() {
  return (
    <div>categoryPage</div>
  )
}
