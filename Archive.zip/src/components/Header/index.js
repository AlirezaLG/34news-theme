import React from "react";
import TopHeader from "../TopHeader";
import Link from "next/link";
import Image from "next/image";
import NavigationMenu from "../NavigationMenu";
import { routeMenu } from "@/lib/helpers";
import { setLanguage } from "@/lib/axios";
// import { useLanguage } from "@/providers/LanguageContext";
import initTranslations from "../../i18n";

export default async function Header({
  primaryMenu,
  topMenu,
  header,
  social1,
  locale,
}) {
  // const { locale, changeLanguage, axiosInstance } = useLanguage();
  // const handleChangeLanguage = (newLocale) => {
  //   changeLanguage(newLocale);
  // };
  const { t, resources } = await initTranslations(locale);
  // console.log(locale);
  return (
    <React.Fragment>
      {/* <TopHeader menu={topMenu} social2={social1} header={header} /> */}
      <div className=" bg-gray-200">
        <di className="container flex py-2">
          <Link href={header.siteUrl ? header.siteUrl : "/"}>
            <Image
              unoptimized
              // {header.headerLogo ? header.headerLogo : "/logo.png"}
              src="/logo.jpg"
              alt={header.siteTitle}
              width={90}
              height={90}
              className="rounded-sm"
              // style={{ width: "auto", height: "auto" }}
            />
          </Link>
          <ul className="ms-auto me-5 flex pt-6">
            {/* {topMenu.menuItems.nodes.map((menuItem) => {
              return (
                <li key={menuItem.id} className="px-3   ">
                  <Link
                    href={routeMenu(menuItem)}
                    target={menuItem.target ? menuItem.target : ""}
                    className="pt-1 text-xs hover:text-primary text-gray-800"
                  >
                    {menuItem.label}
                  </Link>
                </li>
              );
            })} */}
            <li className="px-3   ">
              <Link
                href="/fa"
                className="pt-1 text-xs hover:text-primary text-gray-800"
              >
                Farsi
              </Link>
            </li>
            <li className="px-3">
              <Link
                href="/en"
                className="pt-1 text-xs hover:text-primary text-gray-800"
              >
                English
              </Link>
            </li>
          </ul>
        </di>
      </div>
      <NavigationMenu menu={primaryMenu} header={header} locale={locale} />
    </React.Fragment>
  );
}
