// "use clients";
export const REVALIDATE_DURATION = 1;
//limit word number
export const LIMIT = 30;
export const LIMIT2 = 20;
export const postPerPage = 12;
